\# Crazy Maze

\## 游戏简介

简单的走迷宫小游戏，假装你是一个原始人，展开疯狂的迷宫游戏吧！

\## 操作说明

按箭头键←↑↓→操作角色行动，达到右下角🏆处获得胜利；胜利后，按空格键SPACE刷新迷宫地图，可重新开始游戏。

\## 技术特殊

使用Prim算法和MoonBit提供的Selene游戏框架搭建迷宫场景。

\## 团队信息

团队名称：原始人

成员名单：@Yanoo





素材来源：

https://pixelfrog-assets.itch.io/pixel-adventure-1

https://brackeysgames.itch.io/brackeys-platformer-bundle

