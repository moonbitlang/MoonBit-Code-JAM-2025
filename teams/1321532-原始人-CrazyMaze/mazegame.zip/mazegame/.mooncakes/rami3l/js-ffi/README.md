# js-ffi

**WARNING**: This project is in its alpha phase and not yet production-ready. Use it with care!

`js-ffi` is a library allowing you to interact with basic JavaScript constructs from MoonBit.
