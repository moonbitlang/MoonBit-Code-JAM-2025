# Html wrapper codegen

```
moon run src/experimental/html/internal/codegen > src/experimental/html/generated.mbt
moonfmt -w src/experimental/html/generated.mbt
```