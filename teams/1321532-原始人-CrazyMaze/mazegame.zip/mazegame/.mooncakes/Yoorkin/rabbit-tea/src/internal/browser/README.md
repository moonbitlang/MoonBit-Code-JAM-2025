The `browser` package is deprecated! Please use `@cmd` or `@nav` instead 


